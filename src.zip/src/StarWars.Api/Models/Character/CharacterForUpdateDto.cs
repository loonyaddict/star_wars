﻿using StarWars.Api.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarWars.Api.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class CharacterForUpdateDto : CharacterModelDto, ICharacter
    {
    }
}
