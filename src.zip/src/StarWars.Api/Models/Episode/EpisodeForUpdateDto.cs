﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarWars.Api.Models
{
    /// <summary>
    /// Model for episode update.
    /// </summary>
    public class EpisodeForUpdateDto : EpisodeModelDto
    {
    }
}
