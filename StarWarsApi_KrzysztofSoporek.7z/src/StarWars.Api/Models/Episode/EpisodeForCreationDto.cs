﻿namespace StarWars.Api.Models
{
    /// <summary>
    /// Model for episode creation.
    /// </summary>
    public class EpisodeForCreationDto : EpisodeModelDto
    {
    }
}