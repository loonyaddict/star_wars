﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarWars.API.Services
{
    /// <summary>
    /// Interface for service injection.
    /// </summary>
    public interface IPropertyMapping
    {
    }
}
